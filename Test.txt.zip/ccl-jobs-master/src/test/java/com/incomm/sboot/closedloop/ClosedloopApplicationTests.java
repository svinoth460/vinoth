package com.incomm.sboot.closedloop;

import org.junit.Test;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class ClosedloopApplicationTests {

	@Test
	public void contextLoads() {
	}

}
