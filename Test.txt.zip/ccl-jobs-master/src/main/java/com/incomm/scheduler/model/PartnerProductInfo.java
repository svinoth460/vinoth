package com.incomm.scheduler.model;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PartnerProductInfo {

	private long partnerId;
	private String partnerName;
	private String mdmId;

	private long productId;
	private String productName;

	private long purseId;
	private String purseName;
	private int purseTypeId;

	private Boolean isDefault;


}
