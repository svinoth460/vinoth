package com.incomm.scheduler.service;

public interface PassivePeriodCalculationService {

	public void passivePeriodCalculation();
}
