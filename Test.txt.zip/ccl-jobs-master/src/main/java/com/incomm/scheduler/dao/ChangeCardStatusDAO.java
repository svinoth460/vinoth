package com.incomm.scheduler.dao;

public interface ChangeCardStatusDAO {

	public String changeCardStatus();



}
