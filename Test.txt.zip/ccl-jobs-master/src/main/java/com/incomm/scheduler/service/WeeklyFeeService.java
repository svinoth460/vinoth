package com.incomm.scheduler.service;

public interface WeeklyFeeService {

	public void weeklyFee();
}
