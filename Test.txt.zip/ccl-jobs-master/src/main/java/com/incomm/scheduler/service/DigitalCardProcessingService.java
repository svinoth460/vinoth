package com.incomm.scheduler.service;

public interface DigitalCardProcessingService {
	public void digitalCardProcessing();
}
