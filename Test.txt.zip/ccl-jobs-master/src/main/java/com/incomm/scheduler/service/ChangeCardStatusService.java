package com.incomm.scheduler.service;

public interface ChangeCardStatusService {
	
	public void changeCardStatus();

}
