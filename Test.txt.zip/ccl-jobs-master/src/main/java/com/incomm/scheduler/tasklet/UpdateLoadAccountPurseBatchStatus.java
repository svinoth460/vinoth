package com.incomm.scheduler.tasklet;

import java.util.List;

import com.incomm.scheduler.constants.CCLPConstants;
import com.incomm.scheduler.dao.BatchLoadAccountPurseDAO;
import com.incomm.scheduler.model.BatchLoadAccountPurse;

public class UpdateLoadAccountPurseBatchStatus {

	private BatchLoadAccountPurseDAO batchUpdateRequestDAO;

	public UpdateLoadAccountPurseBatchStatus(BatchLoadAccountPurseDAO batchUpdateRequestDAO) {
		super();
		this.batchUpdateRequestDAO = batchUpdateRequestDAO;
	}

	public void updateBatchRequestStatus(List<BatchLoadAccountPurse> requests) {
		requests.stream()
			.forEach(request -> batchUpdateRequestDAO.updateAccountPurseUpdateRequest(request.getBatchId(),
					CCLPConstants.JOB_STATUS_COMPLETED));
	}

}
