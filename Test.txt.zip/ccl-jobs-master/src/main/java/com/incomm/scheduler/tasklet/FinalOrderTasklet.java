package com.incomm.scheduler.tasklet;

import com.incomm.scheduler.dao.OrderProcessingDAO;

public class FinalOrderTasklet {

	public FinalOrderTasklet(OrderProcessingDAO orderprocessingdao) {
	}

	public void makeProcCall() {
		// make procedure call from here 
	}

}
