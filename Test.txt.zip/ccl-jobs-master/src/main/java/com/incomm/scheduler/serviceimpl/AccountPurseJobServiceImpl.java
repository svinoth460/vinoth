package com.incomm.scheduler.serviceimpl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.incomm.scheduler.constants.PurseType;
import com.incomm.scheduler.constants.ResponseMessages;
import com.incomm.scheduler.dao.BatchLoadAccountPurseDAO;
import com.incomm.scheduler.dao.PartnerDAO;
import com.incomm.scheduler.exception.ServiceException;
import com.incomm.scheduler.model.BatchLoadAccountPurse;
import com.incomm.scheduler.model.PartnerProductInfo;
import com.incomm.scheduler.service.AccountPurseJobService;
import com.incomm.scheduler.service.command.CreatePurseLoadJobCommand;

@Service
public class AccountPurseJobServiceImpl implements AccountPurseJobService {

	@Autowired
	private PartnerDAO partnerDAO;

	@Autowired
	private BatchLoadAccountPurseDAO batchLoadAccountPurseDAO;

	@Override
	public long createPurseLoadJobRequest(CreatePurseLoadJobCommand command) {

		Optional<PartnerProductInfo> partnerProductInfo = partnerDAO.getPartnerProductInfo(command.getPartnerId(), command.getProductId(),
				command.getPurseName());

		if (!partnerProductInfo.isPresent()) {
			throw new ServiceException("Unable to locate partner product configuration for given parameters.",
					ResponseMessages.BAD_REQUEST);
		}

		if (!partnerProductInfo.get()
			.getMdmId()
			.equals(command.getMdmId())) {
			throw new ServiceException("Invalid MDM Id.", ResponseMessages.BAD_REQUEST);
		}

		Optional<PurseType> pursetype = PurseType.byPurseTypeId(partnerProductInfo.get()
			.getPurseTypeId());

		if (!pursetype.isPresent()) {
			throw new ServiceException("Invalid purse Name.", ResponseMessages.BAD_REQUEST);
		}

		if (pursetype.get() == PurseType.SKU && isEmptyOrNull(command.getSkuCode())) {
			throw new ServiceException("Invalid skuCode.", ResponseMessages.BAD_REQUEST);
		}

		long nextBatchId = this.batchLoadAccountPurseDAO.getNextPurseLoadBatchId();

		BatchLoadAccountPurse batchLoadAccountPurse = BatchLoadAccountPurse.builder()
			.batchId(nextBatchId)
			.partnerId(command.getPartnerId())
			.productId(command.getProductId())
			.purseName(command.getPurseName())
			.mdmId(command.getMdmId())
			.transactionAmount(command.getTransactionAmount())
			.effectiveDate(map(command.getEffectiveDate()))
			.expiryDate(map(command.getExpiryDate()))
			.skuCode(command.getSkuCode())
			.actionType(command.getActionType()
				.getAction())
			.overrideCardStatus(
					CollectionUtils.isEmpty(command.getOverrideCardStatus()) ? null : String.join(",", command.getOverrideCardStatus()))
			.status("NEW")
			.insertedDate(LocalDateTime.now())
			.lastUpdatedDate(LocalDateTime.now())
			.build();

		int value = batchLoadAccountPurseDAO.addBatchLoadAccountPurseRequest(batchLoadAccountPurse);
		if (value == 0) {
			throw new ServiceException("Unable to insert record in the database.", ResponseMessages.GENERIC_ERR_MESSAGE);
		}
		return nextBatchId;
	}

	private LocalDateTime map(ZonedDateTime zonedDatetime) {
		ZoneId zoneId = ZoneId.systemDefault();
		return zonedDatetime == null ? null
				: zonedDatetime.withZoneSameInstant(zoneId)
					.toLocalDateTime();
	}

	private boolean isEmptyOrNull(String value) {
		return value == null || value.trim()
			.isEmpty();
	}
}
