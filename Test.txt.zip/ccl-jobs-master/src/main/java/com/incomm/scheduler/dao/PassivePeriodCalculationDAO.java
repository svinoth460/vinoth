package com.incomm.scheduler.dao;

public interface PassivePeriodCalculationDAO {

	public String passivePeriodCalculation();
}
