package com.incomm.scheduler.dao;

public interface DormancyFeeDAO {

	public String callDormancyFeeProcedure();
}
