package com.incomm.scheduler.service;

public interface SerialNumberService {
	
	public void serialNumberRequest();
}
