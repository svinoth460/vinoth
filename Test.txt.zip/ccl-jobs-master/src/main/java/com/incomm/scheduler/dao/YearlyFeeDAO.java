package com.incomm.scheduler.dao;

public interface YearlyFeeDAO {

	public String callYearlyFeeProcedure();
}
