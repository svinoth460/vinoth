package com.incomm.scheduler.service;

public interface DailyBalanceAlertService {

	public String dailyBalanceAlert();

}
