package com.incomm.scheduler.utils;

import java.time.LocalDateTime;

public class DateTimeUtil {

	private DateTimeUtil() {
		// Noop
	}

	public static LocalDateTime map(java.sql.Timestamp timestamp) {
		return timestamp == null ? null : timestamp.toLocalDateTime();
	}

	public static java.sql.Timestamp map(LocalDateTime localDateTime) {
		return localDateTime == null ? null : java.sql.Timestamp.valueOf(localDateTime);
	}

}
