package com.incomm.scheduler.service;

public interface DormancyFeeService {

	public void dormancyFee();
}
