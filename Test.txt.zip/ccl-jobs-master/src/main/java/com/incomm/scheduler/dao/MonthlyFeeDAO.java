package com.incomm.scheduler.dao;

public interface MonthlyFeeDAO {

	public String callMonthlyFeeProcedure();
}
