package com.incomm.scheduler.service;

public interface YearlyFeeService {

	public void yearlyFee() ;
}
