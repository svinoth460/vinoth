package com.incomm.scheduler.service;

public interface MonthlyFeeService {

	public void monthlyFee();
}
