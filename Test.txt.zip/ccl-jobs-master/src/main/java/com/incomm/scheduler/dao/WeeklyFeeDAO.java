package com.incomm.scheduler.dao;

public interface WeeklyFeeDAO {
	
	public String callProcedure();
}
